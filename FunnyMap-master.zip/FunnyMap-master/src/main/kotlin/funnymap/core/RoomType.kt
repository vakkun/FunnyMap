package funnymap.core

enum class RoomType {
    BLOOD,
    CHAMPION,
    ENTRANCE,
    FAIRY,
    NORMAL,
    PUZZLE,
    RARE,
    TRAP
}
