package funnymap.core

enum class DoorType {
    BLOOD,
    ENTRANCE,
    NONE,
    NORMAL,
    WITHER
}
