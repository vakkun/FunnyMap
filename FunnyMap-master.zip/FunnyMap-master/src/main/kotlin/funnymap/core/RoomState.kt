package funnymap.core

enum class RoomState {
    CLEARED,
    DISCOVERED,
    FAILED,
    GREEN,
    UNDISCOVERED
}
