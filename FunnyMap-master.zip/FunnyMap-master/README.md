# FunnyMap

Dungeon map mod for Hypixel Skyblock. Open settings with `/fmap`. Big thanks
to [IllegalMap by UnclaimedBloom6](https://github.com/UnclaimedBloom6/IllegalMap).
